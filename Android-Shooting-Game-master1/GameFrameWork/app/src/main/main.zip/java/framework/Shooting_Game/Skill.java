package framework.Shooting_Game;

import android.graphics.Bitmap;
import android.graphics.Rect;

import framework.gameframework.AppManager;
import framework.gameframework.R;
import framework.gameframework.SpriteAnimation;


class Skill extends SpriteAnimation {
    public static final int STATE_NOMAL = 0;
    public static final int STATE_OUT = 1;
    protected float speed=5f;
    public int state = STATE_NOMAL;
    public long LastShoot = System.currentTimeMillis();


    Rect m_BoundBox = new Rect();

    public Skill(Bitmap bitmap) {
        super(null);
        m_bitmap = AppManager.getInstance().getBitmap(R.drawable.skill);
        m_bitmap = Bitmap.createScaledBitmap(m_bitmap, AppManager.getInstance().getDeviceSize().x, m_bitmap.getHeight(), true);
        this.initSpriteData(getBitmapWidth()/6,getBitmapHeight(),10,6);
    }

    @Override
    public void Update(long GameTime) {
        super.Update(GameTime);
        m_BoundBox.set(getX(), getY(), getX()+getBitmapWidth()/6, getY()+getBitmapHeight());
        move();
    }

    void move() {
        if (getY()== -getBitmapHeight()) {
            state = STATE_OUT;
        }
        setY(getY()-(int)speed);
    }

    void FireRate() {
        if (System.currentTimeMillis() - LastShoot >= 10000) {
            LastShoot = System.currentTimeMillis();

        }
    }
}