package framework.Shooting_Game;


import framework.gameframework.AppManager;
import framework.gameframework.R;

public class Skill_1 extends Skill {


    public Skill_1(int x, int y) {
        super(null);
        this.setPosition(x,y);
        speed = 1.5f;
    }

    public void Update(long GameTime){
        super.Update(GameTime);
        move();
        FireRate();
    }


}
