package framework.Shooting_Game;

import android.graphics.Bitmap;

import framework.gameframework.AppManager;
import framework.gameframework.R;
import framework.gameframework.SpriteAnimation;

public class Skill_Button extends SpriteAnimation {
    public Skill_Button() {
        super(AppManager.getInstance().getBitmap(R.drawable.item4));
        this.initSpriteData(getBitmapWidth()/4,getBitmapHeight(),10,1);
        setPosition(AppManager.getInstance().getDeviceSize().x-getBitmapWidth(),0);
        replay=false;
    }
    public void setReplay(boolean flag){
        replay = flag;
    }
    public boolean getReplay(){return replay;}
}
